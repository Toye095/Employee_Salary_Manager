# Load necessary libraries
library(readr)
library(utils) # use utils for unzip

# Define file paths
zip_file <- "Employee Profile.zip"
output_dir <- "Employee Profile"
csv_file <- file.path(output_dir, "PATRICK GARDNER_details.csv")

# Unzip the folder
if (file.exists(zip_file)) {
  unzip(zip_file, exdir = output_dir)
  message("Unzipping successful.")
} else {
  stop("Error: Zip file does not exist.")
}

# Check if the CSV file was extracted successfully and read it
if (file.exists(csv_file)) {
  employee_data <- read_csv(csv_file)
  print(employee_data)
} else {
  stop("Error: CSV file was not found in the extracted folder.")
}




